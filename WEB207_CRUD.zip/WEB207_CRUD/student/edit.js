app.controller('EditStudentCtrl',function($scope, $http, $location, $routeParams){
    $scope.student = {
        id : '',
        name : '',
        age : '',
        gender : '',
        major : ''
    };
    // Hàm lấy dữ liệu 
    $http({
        method : 'GET',
        url : 'http://localhost:3000/student/' + $routeParams.id
    }).then(function(response){
        $scope.student = response.data;
    })

    // Hàm dùng để cập nhật dữ liệu 
    $scope.onClickUpdate = function(){
        $http({
            method : 'PUT',
            url : 'http://localhost:3000/student/' + $routeParams.id,
            data : $scope.student
        }).then(function(response){
            $scope.student = response.data;
            Swal.fire({
                icon: 'success',
                title: 'Thêm mới thành công!',
                showConfirmButton: false,
                closeOnClickOutside: false,
                allowOutsideClick: false,
                timer: 2600
            });
            $location.path('/list-student');
        })
    }
})