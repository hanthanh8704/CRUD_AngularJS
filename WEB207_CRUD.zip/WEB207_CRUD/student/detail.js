app.controller('DetailStudentCtrl', function($scope, $http, $location, $routeParams){
    $scope.student = {
        id : '',
        name : '',
        age : '',
        gender : '',
        major : ''
    };
    $http({
        method : 'GET',
        url : 'http://localhost:3000/student/' + $routeParams.id
    }).then(function(response){
        $scope.student = response.data;
    })
})