app.controller('CreateStudentCtrl', function($scope, $http, $location){
    $scope.student = {
        id : '',
        name : '',
        age : '',
        gender : '',
        major : ''
    }
    $scope.onClickCreate = function(){
        $http({
            method : 'POST',
            url : 'http://localhost:3000/student',
            data : $scope.student
        }).then(function(response){
            $scope.student = response.data;
            Swal.fire({
                icon: 'success',
                title: 'Thêm mới thành công!',
                showConfirmButton: false,
                closeOnClickOutside: false,
                allowOutsideClick: false,
                timer: 2600
            });
            $location.path('/list-student');
        })
    }
})