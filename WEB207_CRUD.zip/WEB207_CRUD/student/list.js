app.controller('ListStudentCtrl', function($scope, $http){
    $scope.listStudent = [];
    $http({
        method : 'GET',
        url : 'http://localhost:3000/student'
    }).then(function(response){
        $scope.listStudent = response.data;
    })

    $scope.onClickDelete = function(id){
        $http({
            method : 'DELETE',
            url : 'http://localhost:3000/student/' + id
        }).then(function(response){
            Swal.fire({
                icon: 'success',
                title: 'Xóa thành công!',
                showConfirmButton: false,
                closeOnClickOutside: false,
                allowOutsideClick: false,
                timer: 1600
            });
        })
    }
})