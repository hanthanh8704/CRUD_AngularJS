console.log('Log để kiểm tra : Đã nhúng file pages/product/detail.js thành công');

// Khai báo controller detailProductCtrl
// Lưu ý : Khai báo "$routeParams" để có thể lấy giá trị id truyền vào url
app.controller('detailProductCtrl', function($scope, $http, $routeParams){
    console.log('Log để kiểm tra : Khai báo detailProduct thanh cong');

})