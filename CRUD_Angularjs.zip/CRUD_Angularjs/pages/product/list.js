console.log("Log sẽ kiểm tra : Đã nhúng file pages/product/list.js thành công");

// 5.1 khai báo controller listProductCtrl
app.controller("listProductCtrl", function ($scope, $http, $location) {
  console.log("Log để kiểm tra : Khai báo listProductCtrl thành công");
  $scope.danhSachSanPham = [];

  // Function to fetch the product list
  function fetchProductList() {
    $http({
      method: "GET",
      url: "http://localhost:3000/product",
    }).then(function (response) {
      $scope.danhSachSanPham = response.data;
    });
  }

  // Call the fetchProductList function to load the initial product list
  fetchProductList();

  // Biến xử lý validate
  $scope.formMessage = '';
  $scope.formStatus = true;

  // Function to handle product deletion
  $scope.onClickDelete = function (productId) {
    if (confirm("Bạn có chắc chắn muốn xóa sản phẩm này không?")) {
      // Call the API to delete the product
      $http.delete('http://localhost:3000/product/' + productId)
        .then(function (response) {
          // Deletion successful
          console.log("Xóa thành công", response.data);
          alert("Xóa thành công");
          // Fetch the updated product list after deletion
          fetchProductList();
        })
        .catch(function (error) {
          // Deletion failed
          console.error("Xóa thất bại", error);
          alert("Xóa thất bại");
        });
    }
  };
});
