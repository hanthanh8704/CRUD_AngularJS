console.log('Log để kiểm tra : Đã nhúng file pages/product/edit.js thành công');

// Khai báo controller editProductCtrl
// Lưu ý : Khai báo "routeParams" để có thể lấy giá trị id truyền vào url
app.controller('editProductCtrl', function($scope, $http, $routeParams,$location){
    console.log('Log để kiểm tra : Khai báo editProduct thành công');
    console.log('Log để kiểm tra giá trị param từ url :', $routeParams);
    var productId = $routeParams.id;
    console.log("Đã lấy được id của sản phẩm : ",$routeParams)
    // Initialize product object
    $scope.product = {
        id: '',
        name: '',
        price: '',
        category: ''
    };

    // Hàm này dùng để lấy dữ liệu cập nhật
    $http({
        method: 'GET',
        url: 'http://localhost:3000/product/' + productId
    }).then(function (response) {
        // Set product details in the form
        console.log('Lấy ra danh sách thành công', response.data)
        $scope.product = response.data;
    });    

    // Resett validate 
    $scope.formStatus = true;
    $scope.formMessage = '';    

    // Hàm này dùng để hiển thị lại 
    $scope.onClickUpdate = function () {
        let confirmUpdate = window.confirm('Bạn có muốn sửa sản phẩm không?');
        if(confirmUpdate){
            // Check validate
        if($scope.product.id  === ''){
            $scope.formStatus = false;
            $scope.formMessage = 'Mày không được bỏ trống id'
            return // để dừng function luôn
        }else if($scope.product.id  !== productId){
            $scope.formStatus = false;
            $scope.formMessage = 'Tao cấm mày sửa id đấy'
            return // để dừng function luôn
        }       

        // Validate name : Bắt buộc
        if($scope.product.name  === ''){
            $scope.formStatus = false;
            $scope.formMessage = 'Mời bạn nhập name'
            return //
        }        

        // Validate price : Bắt buộc, phải là số, không được nhỏ hơn 1,000,000VNĐ
        if($scope.product.price  === ''){
            $scope.formStatus = false;
            $scope.formMessage = 'Mời bạn nhập price'
            return //
        }else if($scope.product.price === isNaN){
            $scope.formStatus = false;
            $scope.formMessage = 'Tiền phải là số'
            return //
        }else if(Number($scope.product.price) < 1000000){
            $scope.formStatus = false;
            $scope.formMessage = 'Tiền phải lớn hơn 1.000.000'
            return //
        }

        // Validate category : Bắt buộc chọn
        if($scope.product.category === ''){
            $scope.formStatus = false;
            $scope.formMessage = 'Mời bạn nhập category'
            return //
        }

        $http.put('http://localhost:3000/product/' + productId, $scope.product)
            .then(function (response) {
                console.log('Sửa thành công', response.data)
                alert('Sửa thành công');
                $location.path('list-product')
            });
        }
    };
})