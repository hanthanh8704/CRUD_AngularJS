console.log("Log sẽ kiểm tra đã nhúng file pages/product/create.js thành công")

//Khai báo controller createrListProductCtrl
app.controller('createListProductCtrl',function($scope,$http,$location){
    console.log('Log để kiểm tra : Khai báo create thành công');
    // 1.Khai báo các biến chính cần thiết 
    $scope.product = {
        id : '',
        name : '',
        price : '',
        category : ''
    }
    // 3.1.2 : Biến xử lý validate 
    $scope.formMessage = '';
    $scope.formStatus = true; // true là form hợp lệ, false làm form không hợp lệ

    // 2. Liên kết biến với html    | Sử dụng ng-model
    // 2.1 Mở file html để liên kết ng-model



    // 3. Bắt sự kiện và bắt đầu xử lý logic
    // 3.1 Khai báo function với html ng-click
    $scope.onClickCreate = function(){
        let confirmCreate = window.confirm('Bạn có muốn thêm mới sản phẩm không?');
        if(confirmCreate){
            console.log('Log thử giá trị biến $scope.prodcut', $scope.product);

            // 3.1 Validate dữ liệu đầu vào
            // 3.1.1 Thiết kế htmlđc khai báo ở toàn cục controller
            // 3.1.2 Khai báo biến cần thiết cho validate (Biến phải được khai báo ở toàn cục controller)
            // 3.1.3 Liên kết biến vào html
            // 3.1.4 Bắt đầu đi validate
    
            // Resett validate 
            $scope.formStatus = true;
            $scope.formMessage = '';
    
            // Validate id : Bắt buộc
            if($scope.product.id  === ''){
                $scope.formStatus = false;
                $scope.formMessage = 'Mời bạn nhập ID'
                return // để dừng function luôn
            }
    
            // Validate name : Bắt buộc
            if($scope.product.name  === ''){
                $scope.formStatus = false;
                $scope.formMessage = 'Mời bạn nhập name'
                return //
            }        
    
            // Validate price : Bắt buộc, phải là số, không được nhỏ hơn 1,000,000VNĐ
            if($scope.product.price  === ''){
                $scope.formStatus = false;
                $scope.formMessage = 'Mời bạn nhập price'
                return //
            }else if($scope.product.price === isNaN){
                $scope.formStatus = false;
                $scope.formMessage = 'Tiền phải là số'
                return //
            }else if(Number($scope.product.price) < 1000000){
                $scope.formStatus = false;
                $scope.formMessage = 'Tiền phải lớn hơn 1.000.000'
                return //
            }
    
            // Nếu code chạy được đến đây nghĩa là form đã hợp lệ
            console.log('Form hợp lệ')
    
    
            // 3.2 Call api để lưu dữ liệu đầu vào
            $http({
                method : 'POST',
                url : 'http://localhost:3000/product',
                data : $scope.product
            }).then(function(response){
                // Call api thành công
                console.log('Log thành công', response.data);
                // Lưu ý : live server . Sau khi dùng post, put, patch thành công , trình duyệt sẽ sự refresh lại
                alert('Thêm mới thành công', response.data);
                $location.path('list-product')
            })
        }
    }


    //
})